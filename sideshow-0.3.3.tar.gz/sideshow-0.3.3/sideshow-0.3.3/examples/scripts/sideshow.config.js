Sideshow.config.language = "en";
Sideshow.init();