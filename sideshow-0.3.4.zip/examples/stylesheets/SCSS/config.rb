sass_path = File.dirname(__FILE__)
output_path = File.expand_path(File.join(sass_path, '..'))
css_path = output_path 
output_style = :compressed